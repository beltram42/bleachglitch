/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alambert <alambert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 20:59:44 by anthonylamb       #+#    #+#             */
/*   Updated: 2022/05/30 15:24:54 by alambert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lr.h"

void	ft_landmark(void *id[2])
{
	int		x;
	int		y;

	x = 100;
	y = 99;
	while (y++ <= 1000)
		mlx_pixel_put(id[0], id[1], x, y, 0x0009ae51);
	y = 99;
	while (y++ <= 1000)
		if (y == (y / 100) * 100)
		{
			mlx_pixel_put(id[0], id[1], x - 1, y, 0x0009ae51);
			mlx_pixel_put(id[0], id[1], x + 1, y, 0x0009ae51);
		}
	x = 99;
	y = 1000;
	while (x++ <= 2500)
		mlx_pixel_put(id[0], id[1], x, y, 0x0009ae51);
	x = 99;
	while (x++ <= 2500)
	{
		if ((x - 100) == ((x - 100) / 200) * 200)
		{
			mlx_pixel_put(id[0], id[1], x, y - 1, 0x0009ae51);
			mlx_pixel_put(id[0], id[1], x, y + 1, 0x0009ae51);
		}
	}
}

void	ft_trace0(void *id[2], long ldb[6][24], long lv[19])
{
	int	x;
	int	y;
	int	j;
	int	d;

	j = 0;
	while (j < 24)
	{
		x = ldb[km][j] / 400;
		y = ldb[price][j] / 10;
		d = -1;
		while (d <= 1)
		{
			mlx_pixel_put(id[0], id[1], x + d, y, 0x0009ae51);
			mlx_pixel_put(id[0], id[1], x, y + d, 0x0009ae51);
			d++;
		}
		j++;
	}
	x = 0;
	j = 0;
	while (y >= 0)
		y = lv[t0] + (lv[t1] * x++);
}


void	ft_display0(void *id[2], long ldb[6][24], long lv[19])
{
	void	*id[2];

	id[0] = mlx_init();
	id[1] = mlx_new_window(id[0], 1200, 1100, "LR_display");
	ft_landmark(id);
	ft_trace0(id, ldb, lv)
	mlx_loop(id[0]);
}
