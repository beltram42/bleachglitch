/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split5.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alambert <alambert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/26 13:55:05 by lbenatta          #+#    #+#             */
/*   Updated: 2022/04/26 16:43:47 by alambert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
//#include <math.h>

static int	ft_charset(char charset, char a)
{
	if(charset == a)
		return(1);
	else
    	return(0);
}

static int	ft_word(char sep, char *str)
{
	int	i;
	int	wd;
 
	i = 0;
	wd = 0;
	while (ft_charset(sep, str[i]) == 1 && str[i])
		i++;
	while (str[i])
	{
		wd++;
		while (ft_charset(sep, str[i]) == 0 && str[i])
            		i++;
 		while (ft_charset(sep, str[i]) == 1 && str[i])
			i++;
	}
        return (wd);
}

static char	*ft_strdupi(const char *str, char sep)
{
	int	i;
	int	v;
	char	*res;

	i = 0;
	v = 0;
	while (str[i] && ft_charset(sep, str[i]) == 0)
		i++;
	res = (char *)malloc((i + 1) * sizeof (char));
	i = 0;
	if (!res)
    	return (0);
 	while (ft_charset(sep, str[i]) == 1 && str[i])
    		i++;
	while (ft_charset(sep, str[i]) == 0 && str[i])
	{
		res[v] = str[i];
    		i++;
        	v++;
	}
	res[v] = '\0';
	return (res);
}

char       **ft_split(char   const *s, char c)
{
	int	i;
	int	v;
	char	**split;

	split = (char **)malloc((ft_word(c, ((char *)s)) + 1) * sizeof(char *));
	if (!split)
    		return(0);
	v = 0;
	i = 0;
	while (ft_charset(c, s[i]) == 1 && s[i])
    		i++;
	while (s[i])
	{
    		split[v] = ft_strdupi(&s[i], c);
        	if (!split[v])
        		return (0);
        	while (ft_charset(c, s[i]) == 0 && s[i])
        		i++;
        	while (ft_charset(c, s[i]) == 1 && s[i])
        		i++;
		v++;
        }
        split[ft_word(c, ((char *)s))] = 0;
        return (split);
}

char	*get_next_line(int fd);
int	ft_atoi(const char *str);

// ....................... A DEPLACER / A MODIFIER ..............................

typedef struct s_tab
{
	int	km[28];
	int	price[28];
	int	sum_price;
	int	sum_km;
	int	sqr_price[28];
	long	sqr_km[28];
	int	sum_sqr_price;
	long	sum_sqr_km;
	long	pdt[28];
	long	sum_pdt;
	int	count;
}       t_tab;

// .....................................................

void	test(t_tab *tab);
int	main(void)
{
	int	f;
	char	*str;
	char	**strs;
	int	i;
	t_tab *tab;
	//int	prod;
	//int	sqr;
	//char	*memoire;
	//int	taille;

f = open("data.csv", O_RDONLY);

	i = 0;
	tab = (t_tab *)malloc(sizeof(t_tab));
	str = get_next_line(f);
	free(str);
	str = get_next_line(f);
	while (str != NULL)
	{
		strs = ft_split(str, ',');
		tab->km[i] = ft_atoi(strs[0]);
		tab->price[i] = ft_atoi(strs[1]);

        	i++;
		str = get_next_line(f);
	}

	//tab->count = i - 1;
	tab->count = i;

	i = 0;

	while (i < tab->count)
	{
		printf("%i / %i\n", tab->km[i], tab->price[i]);
		i++;
	}
	
	i = 0;
	tab->sum_price = 0;
	tab->sum_km = 0;
	tab->sum_sqr_price = 0;
	tab->sum_sqr_km = 0;

	for(i=0; i < tab->count; i++)
	{
		tab->sum_km = tab->sum_km + tab->km[i];
		tab->sum_price = tab->sum_price + tab->price[i];
		tab->sqr_km[i] = (long)tab->km[i] * (long)tab->km[i];
		tab->sqr_price[i] = tab->price[i] * tab->price[i];
		tab->sum_sqr_km = (long)tab->sum_sqr_km + (long)tab->sqr_km[i];
		tab->sum_sqr_price = tab->sum_sqr_price + tab->sqr_price[i];
		tab->pdt[i] = (long)tab->km[i] * (long)tab->price[i];
		tab->sum_pdt = tab->sum_pdt + tab->pdt[i];
	}

		printf("sum_km : %d\n", tab->sum_km);
		printf("sum_price : %d\n", tab->sum_price);
		printf("sum_sqr_km : %ld\n", tab->sum_sqr_km);
		printf("sum_sqr_price : %d\n", tab->sum_sqr_price);
		printf("sum_pdt : %ld\n", tab->sum_pdt);

		test(tab);
		//free(tab);
		return(0);
}

void test(t_tab *tab)
{
	printf("TOTAL_km : %d\n", tab->sum_km);
	printf("TOTAL_PRICE : %d\n", tab->sum_price);
	printf("TOTAL_sqr_km : %ld\n", tab->sum_sqr_km);
	printf("TOTAL_sqr_PRICE : %d\n", tab->sum_sqr_price);
}
