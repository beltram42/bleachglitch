# MinilibX

This is the MinilibX, a simple X-Window (X11R6) programming API
in C, designed for students, suitable for X-beginners.

## Licence

Copyright Olivier CROUZET - 2014-01-06 -