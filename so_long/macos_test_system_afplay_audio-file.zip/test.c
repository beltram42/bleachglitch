#include <stdlib.h>

int	main()
{
	char	*command = "afplay DrillOut.aiff";
	//char	*command = "ls";

	system(command);
	return (0);
}
