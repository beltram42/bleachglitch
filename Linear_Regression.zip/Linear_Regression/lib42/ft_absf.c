/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_absf.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alambert <alambert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 16:24:41 by alambert          #+#    #+#             */
/*   Updated: 2022/06/06 20:50:17 by alambert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lib42.h"

long double	ft_absld(long double i)
{
	if (i < 0)
		return (-i);
	else
		return (i);
}

double	ft_absd(double i)
{
	return ((double)ft_absld(i));
}

long double	ft_absf(long double i)
{
	if (i < 0)
		return (-i);
	else
		return (i);
}